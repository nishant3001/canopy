<?php
class SolutionController extends Zend_Controller_Action {
	
	public function init(){
		
		
	}
		public function indexAction(){
		}
		


	
	public function healthAction(){
		

    }
		public function financeAction(){
		

    }
			public function telecomAction(){
		

    }
			public function logisticsAction(){
		

    }
			public function  energyAction(){
		

    }
			public function  manufacturingAction(){
		

    }


	

}
?>