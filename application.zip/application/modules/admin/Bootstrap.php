<?php
class Admin_Bootstrap extends Zend_Application_Module_Bootstrap
{
	
	protected function _initAutoload ()
	 { 
		
	 }
	
	protected function _initLibraryAutoloader()
	{
	}
}
?>