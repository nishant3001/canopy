<?php
class ServicesController extends Zend_Controller_Action {
	
	public function init(){
		
		
	}
	
	public function integrationAction(){
		

    }
		public function applicationAction(){
		

    }
			public function dwAction(){
		

    }
			public function consultingAction(){
		

    }
			public function  professionalAction(){
		

    }

			public function  staffAction(){
		

    }


	

}
?>