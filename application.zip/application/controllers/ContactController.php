<?php
class ContactController extends Zend_Controller_Action {
	
	public function init(){
		
		
	}
		


	
	public function vendorAction(){
		

    }
		public function locationsAction(){
		

    }

}
?>