<?php
class AboutController extends Zend_Controller_Action {
	
	public function init(){
		
		
	}
	
	public function indexAction(){
		

    }
		public function coreAction(){
		

    }
			public function overviewAction(){
		

    }
			public function differentiatorsAction(){
		

    }
			public function  alliancesAction(){
		

    }
			public function socialAction(){
		

    }
			public function newsAction(){
		

    }


	

}
?>